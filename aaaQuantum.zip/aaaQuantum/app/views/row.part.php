<tr>
	<td><?php echo $asin; ?></td>
	<td><?php echo $title; ?></td>
	<td><?php echo $mpn; ?></td>
	<td><?php echo $price; ?></td>
</tr>
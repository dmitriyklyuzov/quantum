<?php
	
	define("AWSAccessKeyId", "AKIAIOWFZ4KTTJAKNLFQ");
	define("AssociateTag", "q0d9b-20");
	define("SecretKey", "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");
	define("Service", "AWSECommerceService");
	define("Version", "2013-08-01");

?>